﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MediXpress.Startup))]
namespace MediXpress
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
