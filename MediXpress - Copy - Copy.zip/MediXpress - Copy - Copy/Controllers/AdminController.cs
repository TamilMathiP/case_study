﻿using MediXpress.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace MediXpress.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Care()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(tblAdmin objUser)
        {
            if (ModelState.IsValid)
            {
                using (dbPharmacyEntities3 db = new dbPharmacyEntities3())
                {
                    
                    var obj = db.tblAdmins.Where(a => a.Admin_Username.Equals(objUser.Admin_Username) && a.Admin_Password.Equals(objUser.Admin_Password)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["Username"] = obj.Admin_Username.ToString();
                       

                        return RedirectToAction("AdminDashBoard");
                    }
                    else
                    {
                        MessageBox.Show("Entered Credentials are Wrong");
                    }
                }
            }
            return View(objUser);
        }

        public ActionResult AdminDashBoard()
        {
            if (Session["Username"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        public ActionResult AdminPersonalDetails(string id)
        {
            id = (string)Session["Username"];
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblAdmin admin = db.tblAdmins.Find(id);
            //var storekeepername = (from a in db.tblStoreKeepers where a.User_Name == id select a).FirstOrDefault();
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }
        [HttpGet]
        public ActionResult EditPersonalDetails(string id = null)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblAdmin admin = db.tblAdmins.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditPersonalDetails(tblAdmin admin)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            if (ModelState.IsValid)
            {
                tblAdmin ad = (from u in db.tblAdmins where u.Admin_Username.Equals(admin.Admin_Username) select u).FirstOrDefault();
                //ad.Admin_Username = admin.Admin_Username;
                ad.Admin_Email = admin.Admin_Email;
                ad.Admin_Mobile = admin.Admin_Mobile;
                //db.Entry(store).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("AdminPersonalDetails");
            }
            return View(admin);
        }
        //Register Storekeeper
        [HttpGet]
        public ActionResult RegisterStoreKeeper()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterStoreKeeper(tblStoreKeeper obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (dbPharmacyEntities3 db = new dbPharmacyEntities3())
                    {
                        db.tblStoreKeepers.Add(obj);
                        db.SaveChanges();
                        if (obj != null)
                        {
                            Session["Username"] = obj.User_Name.ToString();

                            return RedirectToAction("StoreKeeperRegistered");
                        }
                    }
                  }
            }
                catch
                {
                    MessageBox.Show("Enter Details Properly");
                }
            

            return View(obj);
            }
            
        
        public ActionResult StoreKeeperRegistered()
        {
            if (Session["Username"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("RegisterStoreKeeper");
            }
        }

        // Details of Patient

        //public actionresult patientdetails()
        //{
        //    dbpharmacyentities3 db = new dbpharmacyentities3();

        //    return view(db.tblforpatientregistrations.tolist());
        //}
        //// get: tblstockdetails/details/5
        //public actionresult details(tblforpatientregistration obj)
        //{


        //    dbpharmacyentities3 db = new dbpharmacyentities3();

        //    var us = (from u in db.tblforpatientregistrations where u.ipatientid == obj.ipatientid select u).firstordefault();
        //    if (us == null)
        //    {

        //        return httpnotfound();
        //    }
        //    return view(us);
        //}
        //// GET: tblStockDetails/Delete/5
        //public ActionResult Delete(string id)
        //{
        //    //if (id == null)
        //    //{
        //    //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    //}
        //    dbPharmacyEntities3 db = new dbPharmacyEntities3();
        //    tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
        //    if (tblStockDetail == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(tblStockDetail);
        //}




        public ActionResult PatientDetails()
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();

            return View(db.tblForPatientRegistrations.ToList());
        }
      





        //change Password for Admin

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordForStoreKeeper ch)
        {
            if (Session["Username"] != null)
            {
                if (ch.newPassword == ch.ConfirmPassword)
                {
                    string user = (Session["Username"].ToString());
                    var pas = ch.oldPassword;
                    try
                    {

                        dbPharmacyEntities3 obj = new dbPharmacyEntities3();
                        var obj1 = (from e in obj.tblAdmins
                                    where e.Admin_Username == user && e.Admin_Password == pas
                                    select e).FirstOrDefault();
                        obj1.Admin_Password = ch.newPassword;
                        obj.SaveChanges();
                        MessageBox.Show("Password has been Changed Successfully!");
                        return RedirectToAction("AdminDashBoard", "Admin");
                    }
                    catch
                    {
                        ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                    return View();

                }
            }
            else
                return RedirectToAction("UserDashBoard", "StoreKeeper");


        }


        public ActionResult AdminLogOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Admin");
        }

        public ActionResult StockDetails()
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();

            return View(db.tblStockDetails.ToList());
        }

        // GET: tblStockDetails/Details/5
        public ActionResult DetailsOfStock(string id)
        {

            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            //tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            var us = (from u in db.tblMedicineDetails where u.cMedicineName == id select u).FirstOrDefault();
            if (us == null)
            {
                //return View("error");
                return HttpNotFound();
            }
            return View(us);
        }
        // GET: tblStockDetails/Delete/5
        public ActionResult Delete(string id)
        {
            //if (id == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            if (tblStockDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblStockDetail);
        }

        // POST: tblStockDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            tblMedicineDetail tblMedicineDetail = db.tblMedicineDetails.Find(id);
            db.tblStockDetails.Remove(tblStockDetail);
            //db.tblMedicineDetails.Remove(tblMedicineDetail);
            db.SaveChanges();
            return RedirectToAction("StockDetails");
        }
        [HttpGet]
        public ActionResult ForgotPassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ForgotPassword(ForgotPasswordForAdmin fp)
        {
            if (fp.newPassword == fp.confirmPassword)
            {
                //string user = Session["abc"].ToString();
                //var pas = ch.oldPassword;
                try
                {

                   dbPharmacyEntities3 obj = new dbPharmacyEntities3();
                    var obj1 = (from e in obj.tblAdmins
                                where e.Admin_Email == fp.vEmail 
                                //&& e.Admin_Mobile == fp.iMobileNum
                                select e).FirstOrDefault();
                    obj1.Admin_Password = fp.newPassword;
                    obj.SaveChanges();
                    MessageBox.Show("Password changed Successfully!!!!");

                    return RedirectToAction("Login", "Admin");
                }
                catch
                {
                    ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                return View();

            }

           

        }

        public ActionResult CheckStockRequest()
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();

            return View(db.tblForStockRequests.ToList());
        }

        // GET: 
        public ActionResult DetailsOfStockRequest(int id)
        {

            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            //tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            var us = (from u in db.tblForStockRequests where u.iRequestId == id && u.dDateofRequest==DateTime.Today select u).FirstOrDefault();
            if (us == null)
            {
               
                return HttpNotFound();
            }
            return View(us);
        }

        [HttpGet]
        public ActionResult DispatchMedicine()
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();

            //var model = (from u in db.tblMedicineDetails
            //             where u.cMedicineName.Equals(obj.cMedicineName)
            //             select u).FirstOrDefault();
            return View();
        }

        [HttpPost]
        //public ActionResult DispatchMedicine(tblMedicineDetail obj)
        //{
        //    dbPharmacyEntities3 db = new dbPharmacyEntities3();
        //   // try
        //   // {

        //        if (ModelState.IsValid)
        //        {
                     
        //            var model = (from u in db.tblMedicineDetails
        //                         where u.cMedicineName.Equals(obj.cMedicineName)
        //                         select u).FirstOrDefault();
        //            model.cSupplierName = obj.cSupplierName;
        //            model.dPrice = obj.dPrice;
        //            model.dExpiryDate = obj.dExpiryDate;
        //            model.iQuantity = obj.iQuantity;
        //            db.SaveChanges();
        //            MessageBox.Show("Medicine is Dispatched!");
                    
        //        }
        //    ///}
        //    //catch 
        //    //{
        //       return View();
        //    //}
        //    //return View();
            
        //}

        public ActionResult Edit(string id)
        {

            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            if (id == null)
            {
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);
            }
            tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            if (tblStockDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblStockDetail);
        }

        // POST: tblStockDetails1/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "cMedicineName,cSupplierName,iQuantity")] tblStockDetail tblStockDetail)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            if (ModelState.IsValid)
            {
                db.Entry(tblStockDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("StockDetails");
            }
            return View(tblStockDetail);
        }


        public ActionResult Create()
        {

            return View();
        }

        // POST: tblStockDetails1/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "cMedicineName,cSupplierName,iQuantity")] tblStockDetail tblStockDetail)
        {

            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            if (ModelState.IsValid)
            {
                db.tblStockDetails.Add(tblStockDetail);
                db.SaveChanges();
                return RedirectToAction("StockDetails");
            }

            return View(tblStockDetail);
        }
    }

}
    