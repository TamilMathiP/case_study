﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MediXpress.Models;
using System.Web.Security;
using System.Windows.Forms;

namespace MediXpress.Controllers
{
    public class StoreKeeperController : Controller
    {
        // GET: StoreKeeper
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            
            return View();
           
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(tblStoreKeeper objUser)
        {
            if (ModelState.IsValid)
            {
                using (dbPharmacyEntities3 db = new dbPharmacyEntities3())
                {

                    tblStoreKeeper obj = db.tblStoreKeepers.Where(a => a.User_Name.Equals(objUser.User_Name) && a.User_Password.Equals(objUser.User_Password)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["Username"] = obj.User_Name.ToString();

                        return RedirectToAction("UserDashBoard");
                    }
                }
            }
            return View(objUser);
        }
        public ActionResult UserDashBoard()
        {
            if (Session["Username"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        } 
        //public ActionResult RegisterPatient()
        //{
        //    return View();
        //}
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult RegisterPatient(tblForPatientRegistration obj)
        //{
        //    try
        //    {
        //        DateTime todaydate = DateTime.Today;
        //        if (ModelState.IsValid)
        //        {
        //            using (dbPharmacyEntities3 db = new dbPharmacyEntities3())
        //            {
        //                var user = (from u in db.tblMedicineDetails
        //                            where u.cMedicineName.Equals(obj.cMedicineName)
        //                            select u).FirstOrDefault();

        //                if(user!=null)
        //                { 
        //                obj.dPrescribedDate = todaydate;
        //                db.tblForPatientRegistrations.Add(obj);
        //                db.SaveChanges();
        //                //if (obj != null)
        //                //{
        //                    Session["Id"] = obj.iPatientId.ToString();

        //                    return RedirectToAction("PatientRegistered");
        //                }
        //                //MessageBox.Show("");
        //                //return RedirectToAction("UserDashBoard");
        //            }


        //        }
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Please Enter Valid Medicine Name");
        //    return View();
        //    }

        //    return View(obj);
        //}



        public ActionResult NewPatientRegistration()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult NewPatientRegistration(tblForPatientRegistration obj)
        {

            if(ModelState.IsValid)

            {

                using (dbPharmacyEntities3 db = new dbPharmacyEntities3())
                 {

                    db.tblForPatientRegistrations.Add(obj);

                    db.SaveChanges();

                    ModelState.Clear();

                    obj = null;
                    MessageBox.Show("Successfully Registration Done");

                    //ViewBag.Message = "Successfully Registration Done";

                }

            }

            return View(obj);
        }



        //public ActionResult PatientRegistered()
        //{
        //    //patient=(string)Session["Username"];
        //    dbPharmacyEntities3 db = new dbPharmacyEntities3();
        //    if (Session["Id"] != null)
        //    {
        //       int a = Convert.ToInt32(Session["Id"]);
        //        var q = db.tblForPatientRegistrations.Where(m => m.iPatientId == a).ToList();
        //        //dbPharmacyEntities3 db = new dbPharmacyEntities3();
        //        ////tblStoreKeeper store = db.tblStoreKeepers.Find(id);
        //        //tblForPatientRegistration pr = db.tblForPatientRegistrations.Find(patient);
        //        return View(q);
        //    }
        //    else
        //    {
        //        return RedirectToAction("RegisterPatient");
        //    }
        //}
        //[HttpGet]
        //public ActionResult CheckStock()
        //{
        //    var db = new dbPharmacyEntities3();
        //    return View(db.tblStockDetails.ToList());
        //}

        //public ActionResult ShowDetails(string obj)
        //{
        //    var db = new dbPharmacyEntities3();
        //    tblStockDetail patient = db.tblStockDetails.Single(a => a.cMedicineName == obj);
        //    if (patient == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(patient);  
        //}
        //public ActionResult Delete(string obj)
        //{
        //    var db = new dbPharmacyEntities3();
        //    tblStockDetail patient = db.tblStockDetails.Single(a => a.cMedicineName == obj);
        //    if (patient == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(patient); 
        //}
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(string abc)
        //{
        //    var db = new dbPharmacyEntities3();
        //    tblStockDetail patient = db.tblStockDetails.Single(a => a.cMedicineName == abc);
        //    db.tblStockDetails.Remove(patient);
        //    db.SaveChanges();
        //    return RedirectToAction("CheckStock");
        //}  
        // GET: tblStockDetails
        public ActionResult StockDetails()
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();

            return View(db.tblStockDetails.ToList());
        }

        // GET: tblStockDetails/Details/
        public ActionResult Details(string id)
        {
            
            //if (id == null)
            //{
            //    //return View ("error");
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            //tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            var us = (from u in db.tblMedicineDetails where u.cMedicineName == id select u).FirstOrDefault();
            if (us == null)
            {
                //return View("error");
                return HttpNotFound();
            }
            return View(us);
        }
        // GET: tblStockDetails/Delete/
        public ActionResult Delete(string id)
        {
            //if (id == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            if (tblStockDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblStockDetail);
        }

        // POST: tblStockDetails/Delete/
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblStockDetail tblStockDetail = db.tblStockDetails.Find(id);
            tblMedicineDetail tblMedicineDetail=db.tblMedicineDetails.Find(id);
            db.tblStockDetails.Remove(tblStockDetail);
            //db.tblMedicineDetails.Remove(tblMedicineDetail);
            db.SaveChanges();
            return RedirectToAction("StockDetails");
        }
        //public ActionResult error()
        //{
        //    return View();
        //}
        //Get
        public ActionResult RequestStock()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RequestStock(tblForStockRequest obj)
        {
            try
            {
                DateTime todaydate = DateTime.Today;
                if (ModelState.IsValid)
                {
                    using (dbPharmacyEntities3 db = new dbPharmacyEntities3())
                    {
                        obj.dDateofRequest = todaydate;
                        db.tblForStockRequests.Add(obj);
                        db.SaveChanges();
                        if (obj != null)
                        {
                            Session["Request id"] = obj.iRequestId.ToString();
                            MessageBox.Show("Stock is Requested.");
                            return RedirectToAction("UserDashBoard");
                        }
                    }


                }
            }
            catch
            {
                MessageBox.Show("Error");
                return View();
            }
            return View(obj);
        }
        //public ActionResult StockRequested()
        //{
        //    if (Session["Medicine Name"] != null)
        //    {
        //        return View();
        //    }
        //    else
        //    {
        //        return RedirectToAction("RequestStock");
        //    }
        //}
        public ActionResult PersonalDetails(string id)
        {
            id = (string)Session["Username"];
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblStoreKeeper store = db.tblStoreKeepers.Find(id);
            //var storekeepername = (from a in db.tblStoreKeepers where a.User_Name == id select a).FirstOrDefault();
            if (store == null)
            {
                return HttpNotFound();
            }
            return View(store);
        }
        [HttpGet]
        public ActionResult EditPersonalDetails(string id = null)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            tblStoreKeeper store = db.tblStoreKeepers.Find(id);
            if (store == null)
            {
                return HttpNotFound();
            }
            return View(store);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditPersonalDetails(tblStoreKeeper store)
        {
            dbPharmacyEntities3 db = new dbPharmacyEntities3();
            if (ModelState.IsValid)
            {
                tblStoreKeeper kp = (from u in db.tblStoreKeepers where u.User_Name.Equals(store.User_Name) select u).FirstOrDefault();
                kp.User_Email = store.User_Email;
                kp.user_mobile = store.user_mobile;
                //db.Entry(store).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("PersonalDetails");
            }
            return View(store);
        } 


        //[HttpGet]
        //public ActionResult ChangePassword(string id = null)
        //{
        //    dbPharmacyEntities3 db = new dbPharmacyEntities3();
        //    tblStoreKeeper store = db.tblStoreKeepers.Find(id);
        //    if (store == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(store);
           
        //}
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult ChangePassword(tblStoreKeeper store)
        //{
        //    //string store=(string)Session["Username"];
        //    dbPharmacyEntities3 db = new dbPharmacyEntities3();
        //    if(ModelState.IsValid)
        //    {
        //        tblStoreKeeper sk = (from a in db.tblStoreKeepers where a.User_Name.Equals(store.User_Name) && a.User_Email.Equals(store.User_Email) && a.user_mobile.Equals(store.user_mobile) select a).FirstOrDefault();
        //        db.Entry(store).State = EntityState.Modified;
        //        db.SaveChanges();
               
        //        return RedirectToAction("UserDashBoard");
        //    }
        //    return View();
        //}


        public ActionResult StoreKeeperLogOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "StoreKeeper");
        }

        //change Password

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordForStoreKeeper ch)
        {
            if (Session["Username"] != null)
            {
                if (ch.newPassword == ch.ConfirmPassword)
                {
                    string user = (Session["Username"].ToString());
                    var pas = ch.oldPassword;
                    try
                    {

                        dbPharmacyEntities3 obj = new dbPharmacyEntities3();
                        var obj1 = (from e in obj.tblStoreKeepers
                                    where e.User_Name == user && e.User_Password == pas
                                    select e).FirstOrDefault();
                        obj1.User_Password = ch.newPassword;
                        obj.SaveChanges();
                        MessageBox.Show("Password is Changed Successfully!");
                        return RedirectToAction("UserDashBoard", "StoreKeeper");
                    }
                    catch
                    {
                        ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                    return View();

                }
            }
            else
                return RedirectToAction("UserDashBoard", "StoreKeeper");


        }

//forgot password for storekeeper

        [HttpGet]
        public ActionResult ForgotPassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ForgotPassword(ForgotPasswordForStoreKeeper fp)
        {
            if (fp.newPassword == fp.confirmPassword)
            {
                //string user = Session["abc"].ToString();
                //var pas = ch.oldPassword;
                try
                {

                    dbPharmacyEntities3 obj = new dbPharmacyEntities3();
                    var obj1 = (from e in obj.tblStoreKeepers
                                where e.User_Email == fp.vEmail && e.user_mobile == fp.iMobileNum
                                select e).FirstOrDefault();
                    obj1.User_Password = fp.newPassword;
                    obj.SaveChanges();

                    return RedirectToAction("Login", "StoreKeeper");
                }
                catch
                {
                    ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                return View();

            }



        }
       
    }
}