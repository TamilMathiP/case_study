
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 06/13/2017 12:18:30
-- Generated from EDMX file: C:\Users\mslceltp1045\Desktop\New folder\MediXpress\Models\MyDatabaseModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [dbPharmacy];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[sysdiagrams]', 'U') IS NOT NULL
    DROP TABLE [dbo].[sysdiagrams];
GO
IF OBJECT_ID(N'[dbo].[tblAdmin]', 'U') IS NOT NULL
    DROP TABLE [dbo].[tblAdmin];
GO
IF OBJECT_ID(N'[dbo].[tblForPatientRegistration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[tblForPatientRegistration];
GO
IF OBJECT_ID(N'[dbo].[tblForStockRequest]', 'U') IS NOT NULL
    DROP TABLE [dbo].[tblForStockRequest];
GO
IF OBJECT_ID(N'[dbo].[tblMedicineDetails]', 'U') IS NOT NULL
    DROP TABLE [dbo].[tblMedicineDetails];
GO
IF OBJECT_ID(N'[dbo].[tblStockDetails]', 'U') IS NOT NULL
    DROP TABLE [dbo].[tblStockDetails];
GO
IF OBJECT_ID(N'[dbo].[tblStoreKeeper]', 'U') IS NOT NULL
    DROP TABLE [dbo].[tblStoreKeeper];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'tblAdmins'
CREATE TABLE [dbo].[tblAdmins] (
    [Admin_Username] varchar(25)  NOT NULL,
    [Admin_Password] varchar(25)  NOT NULL,
    [Admin_Email] varchar(25)  NOT NULL,
    [Admin_Mobile] varchar(25)  NOT NULL
);
GO

-- Creating table 'tblMedicineDetails'
CREATE TABLE [dbo].[tblMedicineDetails] (
    [cMedicineName] char(25)  NOT NULL,
    [cBrandName] char(25)  NOT NULL,
    [cSupplierName] char(25)  NOT NULL,
    [dPrice] decimal(15,0)  NOT NULL,
    [cCategory] char(15)  NOT NULL,
    [dExpiryDate] datetime  NOT NULL,
    [iQuantity] int  NULL
);
GO

-- Creating table 'tblStockDetails'
CREATE TABLE [dbo].[tblStockDetails] (
    [cMedicineName] char(25)  NOT NULL,
    [cSupplierName] char(25)  NOT NULL,
    [iQuantity] int  NULL
);
GO

-- Creating table 'tblStoreKeepers'
CREATE TABLE [dbo].[tblStoreKeepers] (
    [User_Name] varchar(25)  NOT NULL,
    [User_Password] varchar(25)  NOT NULL,
    [User_Email] varchar(25)  NOT NULL,
    [user_mobile] varchar(25)  NOT NULL
);
GO

-- Creating table 'sysdiagrams'
CREATE TABLE [dbo].[sysdiagrams] (
    [name] nvarchar(128)  NOT NULL,
    [principal_id] int  NOT NULL,
    [diagram_id] int IDENTITY(1,1) NOT NULL,
    [version] int  NULL,
    [definition] varbinary(max)  NULL
);
GO

-- Creating table 'tblForStockRequests'
CREATE TABLE [dbo].[tblForStockRequests] (
    [iRequestId] int IDENTITY(1,1) NOT NULL,
    [cMedicineName] char(25)  NOT NULL,
    [iQuantity] int  NOT NULL,
    [dDateofRequest] datetime  NOT NULL
);
GO

-- Creating table 'tblForPatientRegistrations'
CREATE TABLE [dbo].[tblForPatientRegistrations] (
    [iPatientId] int IDENTITY(1,1) NOT NULL,
    [cPatientName] char(25)  NOT NULL,
    [vEmail] varchar(25)  NOT NULL,
    [vContactNo] varchar(25)  NOT NULL,
    [cMedicineName] char(25)  NOT NULL,
    [cPrescribedBy] char(25)  NOT NULL,
    [dPrescribedDate] datetime  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Admin_Username] in table 'tblAdmins'
ALTER TABLE [dbo].[tblAdmins]
ADD CONSTRAINT [PK_tblAdmins]
    PRIMARY KEY CLUSTERED ([Admin_Username] ASC);
GO

-- Creating primary key on [cMedicineName] in table 'tblMedicineDetails'
ALTER TABLE [dbo].[tblMedicineDetails]
ADD CONSTRAINT [PK_tblMedicineDetails]
    PRIMARY KEY CLUSTERED ([cMedicineName] ASC);
GO

-- Creating primary key on [cMedicineName] in table 'tblStockDetails'
ALTER TABLE [dbo].[tblStockDetails]
ADD CONSTRAINT [PK_tblStockDetails]
    PRIMARY KEY CLUSTERED ([cMedicineName] ASC);
GO

-- Creating primary key on [User_Name] in table 'tblStoreKeepers'
ALTER TABLE [dbo].[tblStoreKeepers]
ADD CONSTRAINT [PK_tblStoreKeepers]
    PRIMARY KEY CLUSTERED ([User_Name] ASC);
GO

-- Creating primary key on [diagram_id] in table 'sysdiagrams'
ALTER TABLE [dbo].[sysdiagrams]
ADD CONSTRAINT [PK_sysdiagrams]
    PRIMARY KEY CLUSTERED ([diagram_id] ASC);
GO

-- Creating primary key on [iRequestId] in table 'tblForStockRequests'
ALTER TABLE [dbo].[tblForStockRequests]
ADD CONSTRAINT [PK_tblForStockRequests]
    PRIMARY KEY CLUSTERED ([iRequestId] ASC);
GO

-- Creating primary key on [iPatientId] in table 'tblForPatientRegistrations'
ALTER TABLE [dbo].[tblForPatientRegistrations]
ADD CONSTRAINT [PK_tblForPatientRegistrations]
    PRIMARY KEY CLUSTERED ([iPatientId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------