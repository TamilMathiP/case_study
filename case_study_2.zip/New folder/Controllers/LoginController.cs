﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class LoginController : Controller
    {
        //dbDoctorAppointmentEntities3 db1 = new dbDoctorAppointmentEntities3();
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();
        dbDoctorAppointmentEntities8 db2 = new dbDoctorAppointmentEntities8();
        [HttpGet]
        public ActionResult ReceptionRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ReceptionRegister(tblPatientOfficial1 patientDetail)
        {
            string MESSAGE = string.Empty;
            if (ModelState.IsValid)
            {
                db2.sp_ReceptionistPatient1(patientDetail.iPatientId,patientDetail.cFirstName,patientDetail.cLastName, patientDetail.cDepartment, patientDetail.cDoctorName, patientDetail.cAge, patientDetail.cGender, patientDetail.cAddress, patientDetail.cMobileNumber, patientDetail.dAppointmentDate, patientDetail.cAppointmentTime, patientDetail.cPatientType);
               // db2.tblPatientDetails.Add(tblPatientDetail);
                db2.SaveChanges();
                ViewBag.message = "Registration Successfull";
                MESSAGE = "Registration Successfull";
                System.Windows.Forms.MessageBox.Show(MESSAGE);
                return RedirectToAction("UserHome", "Login");
            }

            return View(patientDetail);
        }
        [HttpGet]
        public ActionResult ViewBookedData()
        {
            //// try
            ////    {
            //string id = (string)Session["UserName"];
            //var model = (from u in db2.tblPatientOfficial1
            //             where u.cFirstName.Equals((string)id)
            //             select u).FirstOrDefault();
            ////if (model == null)
            ////{
            ////    MessageBox.Show("Please Book Your Appointment First");
            ////    return RedirectToAction("ReceptionRegister");
            ////} 

            //// else
            //return View(model);

            ////}
            ////catch (Exception ex)
            ////{

            ////    MessageBox.Show(ex.Message);
            ////}
            //// return View();​



            ////int id = (int)Session["UserID"];
            ////var model = (from u in db1.tblPatientOfficial1
            ////             where u.iPatientId.Equals((int)id)
            ////             select u).FirstOrDefault();

            ////return View(model);

            try
            {
                string id = (string)Session["UserName"];
                var model = (from u in db2.tblPatientOfficial1
                             where u.cFirstName.Equals((string)id)
                             select u).FirstOrDefault();
                if (model == null)
                {
                    MessageBox.Show("Please Book Your Appointment First");
                    return RedirectToAction("ReceptionRegister");
                }

                else
                    return View(model);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            return View();
}
        [HttpGet]
        public ActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(LoginCredentials UserAuthenticate)
        {
            if (ModelState.IsValid)
            {
                if (UserAuthenticate.UserType == "User Login")
                {
                    var obj = db.tblPatientDetails.Where(a => a.cFirstName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.iPatientId;
                        Session["UserName"] = obj.cFirstName.ToString();
                        //Session["Name"] = obj.tblPatientDetail.cFirstName + " " + obj.tblPatientDetail.cLastName;
                        return RedirectToAction("UserHome");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
                else if (UserAuthenticate.UserType == "Receptionist Login")
                {
                    var obj = db.tblLoginHospitals.Where(a => a.cUserName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserId"] = obj.iReceptionistId;
                        Session["UserName"] = obj.cUserName.ToString();
                        Session["Name"] = obj.cRecptionistName;
                        return RedirectToAction("ReceptionistHome", "Reception");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
                else if (UserAuthenticate.UserType == "Doctor Login")
                {
                    var obj = db.tblDepartmentDoctors.Where(a => a.cUserName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserId"] = obj.cUserName;
                        Session["UserName"] = obj.cDoctorName.ToString();
                        return RedirectToAction("DoctorHome", "Doctor");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
                else if (UserAuthenticate.UserType == "Admin Login")
                {
                    var obj = db.tblAdminLogins.Where(a => a.cUserName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserId"] = "Admin Login";
                        Session["UserName"] = "Administrator";
                        return RedirectToAction("AdminHome", "Admin");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
            }
            return View(UserAuthenticate);
        }
        public ActionResult UserHome()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("UserLogin");
            }
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblPatientDetail patientDetail = db.tblPatientDetails.Single(pat => pat.iPatientId == (int)id);
            if (patientDetail == null)
            {
                return HttpNotFound();
            }
            return View(patientDetail);
        }

        public ActionResult Appointment(int id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblPatientOfficial1 patientDetail = db2.tblPatientOfficial1.Where(pat => pat.iPatientId == (int)id).SingleOrDefault();
            if (patientDetail == null)
            {
                return HttpNotFound();
            }

            var model = (from u in db.tblPatientOfficials
                         where u.iPatientId.Equals(id)
                         select u).FirstOrDefault();
            if (model.cDepartment == null)
            {
                return View(patientDetail);
            }
            else
            {
                return RedirectToAction("AppointmentAfter");
            }
            //return View(patientDetail);
        }

        [HttpPost]
        public ActionResult Appointment(int? id, tblPatientOfficial1 patientDetail)
        {
            if (ModelState.IsValid)
            {
                //tblPatientOfficial patientDetail = db.tblPatientOfficials.Single(pat => pat.iPatientId == (int)id);
                db.sp_PatientOfficial((int)id, patientDetail.cDepartment, patientDetail.cDoctorName, patientDetail.dAppointmentDate, patientDetail.cAppointmentTime);
                //db.tblPatientDetails.Add(tblPatientDetail);
                db.SaveChanges();
                ViewBag.message = "Registration Successfull,click ok to login";
                //return RedirectToAction("UserLogin", "Login");
            }
            return View();
        }

        [HttpGet]
        public ActionResult AppointmentAfter()
        {
            int id = (int)Session["UserID"];
            var model = (from u in db.tblPatientOfficials
                         where u.iPatientId.Equals((int)id)
                         select u).FirstOrDefault();

            return View(model);
        }

        public ActionResult DepartmentDoctor(int? id)
        {
            return View(db.tblDepartmentDoctors.ToList());
        }

        public ActionResult Dues(int id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblPatientOfficial1 patientDetail = db2.tblPatientOfficial1.Single(pat => pat.iPatientId == id);
            if (patientDetail == null)
            {
                return HttpNotFound();
            }
            return View(patientDetail);
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult ChangePassword(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Session["UserID"] = (int)id;
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(tblPatientDetail patient)
        {
            //if(ModelState.IsValid)
            //{
                var id = Session["UserID"];

                var x = (from u in db.tblPatientDetails
                             where u.iPatientId.Equals((int)id)
                             select u).Single();
                if (x.cSEcurityQuestion == patient.cSEcurityQuestion && x.cSecurityAnswer == patient.cSecurityAnswer)
                {
                    return RedirectToAction("ChangePassword2","Login");
                }
                else
                {
                    MessageBox.Show("Security questions and answers are not correct please try again");
                    return RedirectToAction("UserHome", "Login");
                }
            //}

            return View(); 
        }

        public ActionResult ChangePassword2()
        {

            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword2(Class1 changePassword)
        {
            if (ModelState.IsValid)
            {
                var x = Session["UserID"];

                var model = (from u in db.tblPatientDetails
                             where u.iPatientId == (int)x 
                             select u).Single();
                model.iPatientId = (int)x;
                model.cPassword = changePassword.NewPassword;

                db.SaveChanges();
                MessageBox.Show("Password Changed Succesfully....!!!");
                return RedirectToAction("UserLogin", "Login");
            }
            return View();
        }

        public ActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPassword(ForgotPassword forgotPassword)
        {
            if (ModelState.IsValid)
            {
                var model = (from u in db.tblPatientDetails
                             where u.cEmailId.Equals(forgotPassword.UserName)
                             select u).FirstOrDefault();
                if (model.cSEcurityQuestion == forgotPassword.SecurityQuestion && model.cSecurityAnswer == forgotPassword.SecurityAnswer)
                {
                    Session["ForgotPassword"] = model.cEmailId;
                    Session["UserId"] = model.iPatientId;
                    return RedirectToAction("ForgotPassword2", "Login");
                }
                else
                {
                    MessageBox.Show("EmailId and Security credentials do not match please contact admin");
                    return RedirectToAction("UserLogin", "Login");
                }
            }

            return RedirectToAction("UserLogin","Login");
        }

        public ActionResult ForgotPassword2()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPassword2(Class1 forgotPassword)
        {
            var x = Session["UserId"];

            var model = (from u in db.tblPatientDetails
                             where u.iPatientId.Equals((int)x)
                             select u).FirstOrDefault();
            model.cPassword = forgotPassword.NewPassword;
            db.SaveChanges();
            MessageBox.Show("Password Reset Successfully");
            return RedirectToAction("UerLogin", "Login"); 
        }
    }
}