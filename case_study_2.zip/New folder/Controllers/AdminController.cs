﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DoctorAppointmentSystem.Controllers
{
    public class AdminController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();
        dbDoctorAppointmentEntities8 db2 = new dbDoctorAppointmentEntities8();
        public ActionResult AdminHome()
        {
            return View();
        }

        public ActionResult DoctorAttendance()
        {
            var model = (from u in db.tblDepartmentDoctors
                         where u.cLeaveStatus.Equals("available")
                         select u).ToList();
            return View(model);
        }

        public ActionResult PatientDetails()
        {
            var model = (from u in db2.tblPatientOfficial1
                         select u).ToList();

            return View(model);
        }

        public ActionResult DepartmentDoctor()
        {
            var model = (from u in db.tblDepartmentDoctors
                         select u).ToList();

            return View(model);
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult DoctorLeave()
        {
            var model = (from u in db.tblDepartmentDoctors
                         where u.cLeaveStatus.Equals("On Leave")
                         select u).ToList();

            return View(model);
        }
    }
}