﻿using casestudy2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace casestudy2.Controllers
{
    public class RegisterController : Controller
    {
        // GET: Register
        public ActionResult Register()
        {
            dcEntities5 db = new dcEntities5();
            var result = db.TblRegisters;
            return View(result);
        }
        [HttpGet]
        public ActionResult Reg()
        {
            TblRegister newRegister = new TblRegister();
            return View();
        }
        [HttpPost]
        public ActionResult Reg(TblRegister t)
        {
            
                if (ModelState.IsValid)
                {
                    dcEntities5 db = new dcEntities5();
                    var item = db.TblRegisters.Where(p => (p.MailId == t.MailId) || ( p.PhoneNumber == t.PhoneNumber)).FirstOrDefault();
              
            if(item == null)
            {

                    db.TblRegisters.Add(t);
                    db.SaveChanges();
                    var lg = new TblLogin();
                    lg.Ro_le = "Customer";
                    lg.UserId = t.UserId;
                    lg.UserPwd = t.UserPwd;
                    db.TblLogins.Add(lg);
                    db.SaveChanges();

                    return RedirectToAction("userview/" + t.UserId);
            }
            else
            {
                
                    ModelState.AddModelError("error", "account already exist");
                    return View();
            }
            
                }
                
            
            
            
            else
                return View(t);
        }
    

        public ActionResult userview(int id)
        {
            dcEntities5 db = new dcEntities5();
            
            @ViewBag.UserId = id;
            return View();
        }
        }
    }
