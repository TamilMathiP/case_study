﻿using casestudy2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace casestudy2.Controllers
{
    public class EditController : Controller
    {
        // GET: Edit
        public ActionResult UserInform1()
        {

            return View();
        }
        public ActionResult Edit()
        {
            if (Session["UserId"] == null)
                return RedirectToAction("login", "Login");
            
             int id = Convert.ToInt32(Session["UserId"].ToString().Trim());
 
            dcEntities5 db = new dcEntities5();

            var result = db.TblRegisters.Where(t => t.UserId == id).FirstOrDefault();
            return View(result);
          
        }

        [HttpPost]
        public ActionResult Edit(TblRegister t)
        {
            if (Session["UserId"] == null)
                return RedirectToAction("login", "Login");
            else
            {
                    dcEntities5 db = new dcEntities5();
                  int id = Convert.ToInt32(Session["UserId"].ToString().Trim());
                  var query = db.TblRegisters.Where(m => t.UserId == id).FirstOrDefault();
              
            
                //TblRegister tb = new TblRegister();
                query.UserName = t.UserName;
                query.PhoneNumber = t.PhoneNumber;
                query.UserAddress = t.UserAddress;
                query.MailId = t.MailId;
              
                db.SaveChanges();
                return RedirectToAction("UserInform1");
            }


       
        }
    }
}

