﻿using casestudy2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace casestudy2.Controllers
{
    public class SappointmentController : Controller
    {
        // GET: Appointment
        public ActionResult ViewApproval()
        {
            dcEntities5 db = new dcEntities5();
            return View();

        }
        public ActionResult StaffInform()
        {

            return View();
        }
        public ActionResult Sappointment()
        {
            dcEntities5 db = new dcEntities5();
            var result = db.TblPatientAppointments;
            return View();
        }
        [HttpGet]
        public ActionResult Index()
        {
            dcEntities5 db = new dcEntities5();
            TblPatientAppointment newReg = new TblPatientAppointment();
            return View();
        }
        [HttpPost]
        public ActionResult Index(TblPatientAppointment m)
        {
            dcEntities5 db = new dcEntities5();
            if (ModelState.IsValid)
            {

                db.TblPatientAppointments.Add(m);
                db.SaveChanges();
                return RedirectToAction("StaffInform");
            }
            else
                return View(m);
        }
        public ActionResult Approve()
        {
            dcEntities5 db = new dcEntities5();
            var result = db.TblPatientAppointments.Where(m => m.sta_tus.Equals("Pending")).ToList();
            if (result != null)
                return View(result);
            else
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
        }

        public ActionResult approvalB(int ? id)
        {
            if (ModelState.IsValid)
            {
                dcEntities5 db = new dcEntities5();
                var item = db.TblPatientAppointments.Where(m => m.ApplicationId == id).FirstOrDefault();
                item.sta_tus = "Approve";
                db.SaveChanges();
                return RedirectToAction("Approve");
             

            }
            else
            {
                return RedirectToAction("Approve");
            }
        }
        public ActionResult approvalc(int id)
        {
            if (ModelState.IsValid)
            {
                dcEntities5 db = new dcEntities5();
                var item = db.TblPatientAppointments.Where(m => m.ApplicationId == id).FirstOrDefault();
                item.sta_tus = "Decline";
                db.SaveChanges();
                return RedirectToAction("Approve");


            }
            else
            {
                return RedirectToAction("Approve");
            }

        }
          
        public ActionResult test(testdetail e)
        {
           
               
              dcEntities5 db = new dcEntities5();
                var result = db.testdetails.ToList();
                if (result != null)
                    return View(result);
                else
                    return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }​
            
            
        


      
    }
}

